package com.employeeCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
